extern crate amethyst;

struct Example;

impl amethyst::State for Example {
    fn new() -> Self {
        Example
    }

    fn update(&mut self, _delta: amethyst::Duration) {
        println!("Hello from Amethyst!");
        std::process::exit(0);
    }
}

fn main() {
    let mut game = amethyst::Application::new(Example);
    game.run();
}
